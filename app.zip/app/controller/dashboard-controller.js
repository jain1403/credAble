var app= angular.module('myApp');
app.controller('dashboardCtrl',function($scope,$state,$rootScope){
    console.log("In dashboard");
});

